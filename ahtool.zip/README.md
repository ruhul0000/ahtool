## Ahrefs PHP API Client ##

Wrapper for [Ahrefs](https://ahrefs.com) [API V2](https://ahrefs.com/api/)

## Usage ##

Look inside index.php for example usage, or use the [API Request Builder](https://ahrefs.com/api/api-request-builder) to generate the code.
